# SayanthRock.github.io

Personal portfolio website for **Sayanth Rock**, hosted free with GitHub Pages.

## Publish

1. Upload `index.html` to the repository root.
2. Open **Settings → Pages**.
3. Set **Source** to **Deploy from a branch**.
4. Select **main** and **/(root)**.
5. Save.

Website: https://sayanthrock.github.io
